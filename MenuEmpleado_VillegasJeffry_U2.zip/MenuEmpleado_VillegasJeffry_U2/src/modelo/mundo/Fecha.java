package modelo.mundo;

public class Fecha {
	private int dia;
	private int mes;
	private int anio;

	//Constructor
	public Fecha (int pDia, int pMes, int pAnio) {
		dia = pDia;
		mes = pMes;
		anio = pAnio;
	}

	// M. analizadores getters
	public int getDia() {
		return dia;
	}
	public int getMes() {
		return mes;
	}
	public int getAnio() {
		return anio;
	}

	// M. funcionales
	public int darDiferenciaEnMeses (Fecha pFecha) {
		int numeroMeses = 0;
		int difAnios =  pFecha.getAnio();
		int difMes = pFecha.getMes( );
        int difDia = pFecha.getDia( );

		numeroMeses = 12 * (difAnios - anio) + (difMes - mes);
		if(difDia < dia ) {
			numeroMeses --;
		}
			
		return numeroMeses;
	}
	
	//Formato de Fecha
	public String toString() {
		return dia + "-"  + mes +"-" + anio;
	}

}
