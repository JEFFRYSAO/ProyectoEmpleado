
package modelo.mundo;

import java.util.Scanner;

import java.util.InputMismatchException;

public class Principal {

	static Scanner entrada = new Scanner(System.in);
	public static void main(String[] args) {

		

		
		Empleado empleado1 = null;

		String nombreEmple;
		String apellidoEmple;
		int genero;
		
		double salario;
		int dia, mes ,anio;
		Fecha fechaNac;
		Fecha fechaIngreso;

		// MENU

		@SuppressWarnings("resource")
		Scanner sn = new Scanner(System.in);
		int opcion=0;
		do {
			System.out.println("\n---------------------------------------------------------------");
			System.out.println("                      MENU DE OPCIONES                        ");
			System.out.println("---------------------------------------------------------------");
			System.out.println(" 1). Ingrese datos del empleado.                        ");
			System.out.println(" 2). Calcular la edad del empleado                      ");
			System.out.println(" 3). Calcular la antig�edad del empleado en la empresa  ");
			System.out.println(" 4). Calcular las prestaciones del empleado.            ");
			System.out.println(" 5). Visualizar la informaci�n del empleado             ");
			System.out.println(" 6). SALIR                                              ");
			System.out.println("---------------------------------------------------------------");
			try {
				System.out.println("\n* Escoja una de las opciones: ");
				opcion = sn.nextInt();
			}
			catch(InputMismatchException e) { 
				System.out.println(" ***** Ingresa solo numeros *****");
				opcion=6;
				e.printStackTrace();
			}

			switch(opcion){
			case 1:
	
				System.out.println("-> Ingresa tus Nombres  : ");                              
				nombreEmple= entrada.nextLine();
				System.out.println("-> Ingresa tus Apellidos:   ");                             
				apellidoEmple= entrada.nextLine();
				

				do {
					try {
						System.out.println("-> Ingresa tu Genero [1]Masculino y [2]Femenino :      ");
						genero= entrada.nextInt();

					}
					catch(InputMismatchException e) {
						System.out.println(" ***** Debe ingresar solo n�meros ***** ");
						genero = 0;
						
						entrada.nextInt();
					}
				}while (genero<1 || genero>2);

				do {
					try {
						System.out.println("-> Ingresa tu Salario entre $490 y $800 :    ");
						salario = entrada.nextDouble();
					}
					catch(InputMismatchException e) {
						System.out.println(" ***** Salario entre $490 y $800 *****");
						salario = 0;
						e.printStackTrace();	
					}
				}while (salario<490 || salario>800);

				do {
					System.out.println("-> Ingresa tu Dia de Nacimiento entre [01] y [31] :");
					dia = entrada.nextInt();
				}while (dia<01 || dia>31);

				do {
					System.out.println("-> Ingresa tu Mes de Nacimiento  entre [01] y [12] :  ");
					mes = entrada.nextInt();
				}while (mes<01 || mes>12);

				do {
					System.out.println("-> Ingresa tu A�o de Nacimiento entre [1970] y [2021] :");
					anio = entrada.nextInt();
					fechaNac= new Fecha (dia, mes,anio);
				}while (anio<1970 || anio>2021);
				System.out.println("---------------------------------------------------------------");
				System.out.println("---------------------------------------------------------------");
				do {
					System.out.println("-> Ingresa tu Dia de ingreso a la empresa entre [01] y [31] :");
					dia = entrada.nextInt();	
				}while (dia<01 || dia>31);

				do {
					System.out.println("-> Ingresa tu Mes de ingreso a la empresa  entre [01] y [12] :");
					mes = entrada.nextInt();	
				}while (mes<01 || mes>12);

				do {

					System.out.println("-> Ingresa tu A�o de ingreso a la empresa entre [1980] y [2021] :");
					anio = entrada.nextInt();
				}while (anio<1980 || anio>2021);

				fechaIngreso= new Fecha (dia, mes,anio);
				empleado1=new Empleado(nombreEmple, apellidoEmple, genero, salario, fechaNac, fechaIngreso);
				break;

			case 2:
				
				System.out.println("\n* Su edad es:" +empleado1.calcularEdad());
				break;

			case 3:
				
				System.out.println("\n* Su antiguedad en la empresa es:" +empleado1.calcularAntiguedad());
				break;

			case 4:
				
				System.out.println("\n* Sus prestaciones son:" +empleado1.calcularPrestaciones());
				break;

			case 5:
				System.out.println("------------------------------------------------------");
				System.out.println("            INFORMACION DEL EMPLEADO               ");
				System.out.println("------------------------------------------------------");
				empleado1.mostrarInformacion();
				break;

			case 6:
				System.out.println("            **** GRACIAS ****               ");
				System.out.println("     -------------------------------     ");
				System.out.println("         **** VUELVA PRONTO ****               ");
			
				break;

			default:
				
				System.out.println("       < < OPCION INCORRECTA > >               ");
				System.out.println("     -------------------------------     ");
				System.out.println("      < < INGRESE ENTRE 1 Y 6 > >           ");
				
			}
		}while(opcion!=6);

	}	
}
